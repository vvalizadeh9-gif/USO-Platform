import { lazy, Suspense } from 'react'
import { Navigate, Route, Routes } from 'react-router-dom'
import Layout from './components/Layout'
import { useAuth } from './context/AuthContext'
import { Loading } from './components/ui'
import Login from './pages/Login'

// Route pages are code-split so the initial load only ships the shell +
// current page. Each page's JS (and its heavy deps like charts) is fetched on
// demand, making first paint and navigation noticeably faster.
const DriveTestProject = lazy(() => import('./pages/DriveTestProject'))
const HealthCheck = lazy(() => import('./pages/HealthCheck'))
const MyHealthCheck = lazy(() => import('./pages/MyHealthCheck'))
const WorkItems = lazy(() => import('./pages/WorkItems'))
const WorkItemDetail = lazy(() => import('./pages/WorkItemDetail'))
const ActionCenter = lazy(() => import('./pages/ActionCenter'))
const Acceptance = lazy(() => import('./pages/Acceptance'))
const Admin = lazy(() => import('./pages/Admin'))

function Protected({ children, adminOnly }) {
  const { user, loading, isAdmin } = useAuth()
  if (loading) return <Loading />
  if (!user) return <Navigate to="/login" replace />
  if (adminOnly && !isAdmin) return <Navigate to="/" replace />
  return children
}

export default function App() {
  const { user } = useAuth()

  return (
    <Suspense fallback={<Loading />}>
      <Routes>
        <Route path="/login" element={user ? <Navigate to="/" replace /> : <Login />} />
        <Route
          element={
            <Protected>
              <Layout />
            </Protected>
          }
        >
          <Route path="/" element={<Navigate to="/work-items" replace />} />
          <Route path="/drive-test" element={<DriveTestProject />} />
          <Route path="/health-check" element={<HealthCheck />} />
          <Route path="/my-health-check" element={<MyHealthCheck />} />
          <Route path="/work-items" element={<WorkItems />} />
          <Route path="/work-items/:id" element={<WorkItemDetail />} />
          <Route path="/action-center" element={<ActionCenter />} />
          <Route path="/notifications" element={<Navigate to="/action-center" replace />} />
          <Route path="/acceptance" element={<Acceptance />} />
          <Route path="/admin" element={<Protected adminOnly><Admin /></Protected>} />
        </Route>
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </Suspense>
  )
}
