import { motion } from 'framer-motion'
import { Radio, ArrowRight } from 'lucide-react'
import { useEffect, useState } from 'react'
import api from '../api/client'
import { EmptyState, Loading, PageHead, fadeUp, stagger } from '../components/ui'

const CATEGORY_COLOR = {
  drive_test: 'var(--signal)',
  assignment: 'var(--violet)',
  acceptance: 'var(--green)',
}

export default function ActionCenter() {
  const [items, setItems] = useState(null)

  useEffect(() => {
    api.get('/action-center').then((r) => setItems(r.data)).catch(() => setItems([]))
  }, [])

  if (!items) return <Loading label="Loading your actions" />

  const totalPending = items.reduce((sum, i) => sum + i.count, 0)

  return (
    <>
      <PageHead
        eyebrow="My work"
        title="Action Center"
        subtitle="Pending activities that need your attention, derived automatically from current state."
      />

      {items.length === 0 || totalPending === 0 ? (
        <div className="card"><EmptyState title="You're all caught up" hint="No pending actions right now." /></div>
      ) : (
        <motion.div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(260px, 1fr))' }} variants={stagger} initial="hidden" animate="show">
          {items.map((item) => (
            <motion.div
              key={item.label}
              className="card card-pad"
              variants={fadeUp}
              whileHover={{ y: -3 }}
              style={{ borderLeft: `3px solid ${CATEGORY_COLOR[item.category] || 'var(--signal)'}` }}
            >
              <div className="row between">
                <Radio size={18} style={{ color: CATEGORY_COLOR[item.category] || 'var(--signal)' }} />
                <span className="tnum" style={{ fontFamily: 'var(--font-display)', fontSize: 30, fontWeight: 600 }}>
                  {item.count}
                </span>
              </div>
              <div style={{ marginTop: 10, fontWeight: 500 }}>{item.label}</div>
              <div className="row" style={{ marginTop: 6, color: 'var(--text-dim)', fontSize: 12.5 }}>
                <span style={{ textTransform: 'capitalize' }}>{item.category.replace('_', ' ')}</span>
                <ArrowRight size={13} />
              </div>
            </motion.div>
          ))}
        </motion.div>
      )}
    </>
  )
}
