import { motion } from 'framer-motion'
import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import api from '../api/client'
import { useAuth } from '../context/AuthContext'
import { useToast } from '../context/ToastContext'

export default function Login() {
  const { login } = useAuth()
  const toast = useToast()
  const navigate = useNavigate()
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [captcha, setCaptcha] = useState(null)
  const [captchaAnswer, setCaptchaAnswer] = useState('')
  const [busy, setBusy] = useState(false)

  useEffect(() => {
    refreshCaptcha()
  }, [])

  async function refreshCaptcha() {
    setCaptchaAnswer('')
    const { data } = await api.get('/auth/captcha')
    setCaptcha(data)
  }

  async function onSubmit(e) {
    e.preventDefault()
    if (!/^-?\d+$/.test(captchaAnswer.trim())) {
      toast.error('Sign in failed', 'Enter the captcha answer as a number.')
      return
    }
    setBusy(true)
    try {
      await login(username, password, captcha.token, captchaAnswer.trim())
      navigate('/')
    } catch (err) {
      if (err.response?.status === 400) {
        toast.error('Sign in failed', 'Captcha answer is incorrect. Try again.')
      } else {
        toast.error('Sign in failed', 'Check your username and password.')
      }
      refreshCaptcha()
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="login-wrap">
      <motion.div
        className="login-card"
        initial={{ opacity: 0, y: 20, scale: 0.98 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
      >
        <div className="brand">
          <div className="brand-mark"><span>U</span></div>
          <div className="brand-text">
            <b>USO Platform</b>
            <small>Enterprise Operations</small>
          </div>
        </div>

        <div style={{ textAlign: 'center', marginBottom: 24 }}>
          <h2 style={{ fontSize: 20 }}>Sign in to continue</h2>
          <p className="muted" style={{ marginTop: 4, fontSize: 13 }}>
            Enter your credentials to access the platform
          </p>
        </div>

        <form onSubmit={onSubmit}>
          <div className="field">
            <label>Username</label>
            <input
              className="input"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="your.username"
              autoFocus
              required
            />
          </div>
          <div className="field">
            <label>Password</label>
            <input
              className="input"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              required
            />
          </div>
          <div className="field">
            <label>{captcha ? `What is ${captcha.num1} + ${captcha.num2}?` : 'Loading captcha…'}</label>
            <input
              className="input"
              type="text"
              inputMode="numeric"
              value={captchaAnswer}
              onChange={(e) => setCaptchaAnswer(e.target.value)}
              placeholder="Your answer"
              required
              disabled={!captcha}
            />
          </div>
          <button className="btn btn-primary" style={{ width: '100%', justifyContent: 'center', marginTop: 6 }} disabled={busy || !captcha}>
            {busy ? <div className="spinner" /> : 'Sign in'}
          </button>
        </form>
      </motion.div>
    </div>
  )
}
