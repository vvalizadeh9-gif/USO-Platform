import { motion } from 'framer-motion'
import { useEffect, useState } from 'react'
import api from '../api/client'
import { useAuth } from '../context/AuthContext'
import { useToast } from '../context/ToastContext'
import { EmptyState, Loading, PageHead, StatusPill } from '../components/ui'

const TECHS = ['2G', '3G', '4G']
const STATUSES = ['Pending', 'Approved', 'Rejected']

// Aggregates villages across visible work items so coordinators can
// update ICT/CRA acceptance per technology in one place.
export default function Acceptance() {
  const [rows, setRows] = useState(null)
  const { user } = useAuth()
  const toast = useToast()
  const canEdit = ['Admin', 'PM', 'Coordinator'].includes(user?.role?.name)

  async function load() {
    setRows(null)
    const { data } = await api.get('/work-items/acceptance/overview')
    setRows(data)
  }
  useEffect(() => { load().catch(() => setRows([])) }, [])

  async function update(villageId, tech, patch) {
    try {
      await api.patch(`/villages/${villageId}/acceptance/${tech}`, patch)
      toast.success('Acceptance updated')
      await load()
    } catch (err) {
      toast.error('Update failed', err.response?.data?.detail || 'Please try again.')
    }
  }

  if (!rows) return <Loading label="Loading acceptance data" />

  return (
    <>
      <PageHead
        eyebrow="Regulatory"
        title="Acceptance"
        subtitle="ICT and CRA approval status per village, per technology. Updates apply immediately."
      />

      {rows.length === 0 ? (
        <div className="card"><EmptyState title="No villages to show" hint="Import a CPM file to populate villages." /></div>
      ) : (
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Village</th>
                <th>Work Item</th>
                {TECHS.map((t) => <th key={t}>{t}</th>)}
              </tr>
            </thead>
            <tbody>
              {rows.map(({ work_item_id, site_type, village }, i) => (
                <motion.tr key={village.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: Math.min(i * 0.015, 0.3) }}>
                  <td style={{ fontWeight: 500 }}>{village.village_name || village.village_code || '—'}</td>
                  <td className="dim">#{work_item_id} · {site_type}</td>
                  {TECHS.map((t) => {
                    const acc = village.acceptances.find((a) => a.technology === t)
                    return (
                      <td key={t}>
                        {canEdit ? (
                          <div className="row" style={{ gap: 6 }}>
                            <SelectPill
                              value={acc?.ict_status || 'Pending'}
                              onChange={(val) => update(village.id, t, { ict_status: val })}
                              tag="ICT"
                            />
                            <SelectPill
                              value={acc?.cra_status || 'Pending'}
                              onChange={(val) => update(village.id, t, { cra_status: val })}
                              tag="CRA"
                            />
                          </div>
                        ) : (
                          <div className="row" style={{ gap: 6 }}>
                            <StatusPill status={acc?.ict_status || 'Pending'} />
                            <StatusPill status={acc?.cra_status || 'Pending'} />
                          </div>
                        )}
                      </td>
                    )
                  })}
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </>
  )
}

function SelectPill({ value, onChange, tag }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
      <span style={{ fontSize: 10, color: 'var(--text-dim)', letterSpacing: '0.05em' }}>{tag}</span>
      <select
        className="input"
        style={{ padding: '4px 8px', fontSize: 12.5, width: 'auto' }}
        value={value}
        onChange={(e) => onChange(e.target.value)}
      >
        {STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
      </select>
    </div>
  )
}
