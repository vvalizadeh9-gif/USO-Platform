import { motion } from 'framer-motion'
import { Bell, Check } from 'lucide-react'
import { useEffect, useState } from 'react'
import api from '../api/client'
import { EmptyState, Loading, PageHead } from '../components/ui'

export default function Notifications() {
  const [items, setItems] = useState(null)

  function load() {
    api.get('/notifications').then((r) => setItems(r.data)).catch(() => setItems([]))
  }
  useEffect(load, [])

  async function markRead(id) {
    await api.post(`/notifications/${id}/read`)
    load()
  }

  if (!items) return <Loading label="Loading notifications" />

  return (
    <>
      <PageHead eyebrow="Inbox" title="Notifications" subtitle="System events relevant to your role." />

      {items.length === 0 ? (
        <div className="card"><EmptyState title="No notifications" hint="You'll see workflow events here as they happen." /></div>
      ) : (
        <div className="grid" style={{ gap: 10 }}>
          {items.map((n, i) => (
            <motion.div
              key={n.id}
              className="card card-pad row between"
              initial={{ opacity: 0, x: -8 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: Math.min(i * 0.03, 0.4) }}
              style={{ borderLeft: `3px solid ${n.is_read ? 'var(--border)' : 'var(--signal)'}` }}
            >
              <div className="row" style={{ gap: 12 }}>
                <Bell size={17} style={{ color: n.is_read ? 'var(--text-dim)' : 'var(--signal)' }} />
                <div>
                  <div style={{ fontWeight: n.is_read ? 400 : 500 }}>{n.message}</div>
                  <small className="dim">{n.type}</small>
                </div>
              </div>
              {!n.is_read && (
                <button className="btn btn-sm btn-ghost" onClick={() => markRead(n.id)}>
                  <Check size={14} /> Mark read
                </button>
              )}
            </motion.div>
          ))}
        </div>
      )}
    </>
  )
}
