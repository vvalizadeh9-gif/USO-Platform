import { AnimatePresence, motion } from 'framer-motion'
import { UploadCloud, Users, GitCompare } from 'lucide-react'
import { useEffect, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import api from '../api/client'
import { PageHead } from '../components/ui'
import CpmImportTab from './admin/CpmImportTab'
import UsersTab from './admin/UsersTab'
import ValidateCpmTab from './admin/ValidateCpmTab'

const TABS = [
  { key: 'import', label: 'CPM Import', icon: UploadCloud },
  { key: 'users', label: 'Users & Permissions', icon: Users },
  { key: 'validate', label: 'Validate CPM', icon: GitCompare },
]

export default function Admin() {
  // Deep-linked from Action Center: ?tab=validate&highlight=<change-request-id>
  const [searchParams] = useSearchParams()
  const [tab, setTab] = useState(searchParams.get('tab') || 'import')
  const highlightId = searchParams.get('highlight')
  const [pendingCount, setPendingCount] = useState(0)

  function refreshPending() {
    api.get('/admin/cpm/change-requests/count')
      .then((r) => setPendingCount(r.data.pending || 0))
      .catch(() => {})
  }
  useEffect(() => {
    refreshPending()
  }, [tab])

  return (
    <>
      <PageHead
        eyebrow="Administration"
        title="Admin Console"
        subtitle="Import master data, manage user access, and review CPM changes."
      />

      <div className="tabs">
        {TABS.map((t) => (
          <button key={t.key} className={`tab ${tab === t.key ? 'active' : ''}`} onClick={() => setTab(t.key)}>
            <span className="row" style={{ gap: 8 }}>
              <t.icon size={15} /> {t.label}
              {t.key === 'validate' && pendingCount > 0 && (
                <span
                  style={{
                    minWidth: 18,
                    height: 18,
                    padding: '0 5px',
                    borderRadius: 9,
                    background: 'var(--red)',
                    color: '#fff',
                    fontSize: 11,
                    fontWeight: 700,
                    display: 'inline-flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    lineHeight: 1,
                  }}
                >
                  {pendingCount > 99 ? '99+' : pendingCount}
                </span>
              )}
            </span>
          </button>
        ))}
      </div>

      <AnimatePresence mode="wait">
        <motion.div
          key={tab}
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -8 }}
          transition={{ duration: 0.2 }}
        >
          {tab === 'import' && <CpmImportTab />}
          {tab === 'users' && <UsersTab />}
          {tab === 'validate' && <ValidateCpmTab onDecided={refreshPending} highlightId={highlightId} />}
        </motion.div>
      </AnimatePresence>
    </>
  )
}
