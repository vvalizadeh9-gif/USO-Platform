"""Health Check workflow models (Phase A).

Replaces the old single-flag ``health_checks`` table with a fuller,
assignment-based model:

* HcAssignment  — a container: many sites assigned to one subcontractor.
* HcTask        — one site inside an assignment (independent per-site result).
* HcTaskTechnology — the subcontractor's Normal/NotNormal answer per requested
  technology. Only technologies the site actually requested are ever created.

The site's overall Ready / NotReady is computed from its technology rows, not
entered manually (see services/health_check.py).
"""
from __future__ import annotations

from datetime import datetime

from sqlalchemy import (
    Boolean,
    DateTime,
    ForeignKey,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.database import Base


class HcAssignment(Base):
    """A coordinator's assignment of many sites to one subcontractor for HC."""

    __tablename__ = "hc_assignments"

    id: Mapped[int] = mapped_column(primary_key=True)
    code: Mapped[str] = mapped_column(String(30), unique=True, nullable=False)
    contractor_id: Mapped[int] = mapped_column(
        ForeignKey("contractors.id"), nullable=False, index=True
    )
    assigned_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    assigned_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    status: Mapped[str] = mapped_column(
        String(20), default="Open", nullable=False
    )  # Open | Completed
    remarks: Mapped[str | None] = mapped_column(Text)

    contractor = relationship("Contractor")
    tasks: Mapped[list[HcTask]] = relationship(
        back_populates="assignment", lazy="selectin"
    )


class HcTask(Base):
    """One site inside an HC assignment. Independent per-site result."""

    __tablename__ = "hc_tasks"
    __table_args__ = (
        UniqueConstraint("hc_assignment_id", "work_item_id", name="uq_hc_task_site"),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    hc_assignment_id: Mapped[int] = mapped_column(
        ForeignKey("hc_assignments.id"), nullable=False, index=True
    )
    work_item_id: Mapped[int] = mapped_column(
        ForeignKey("work_items.id"), nullable=False, index=True
    )
    # Auto-computed from the technology rows: None (pending) | Ready | NotReady
    overall_result: Mapped[str | None] = mapped_column(String(20))
    # Only set when NotReady — one of the 4 predefined problem categories.
    # Set by a Coordinator/PM during validation (NOT by the subcontractor).
    problem_category: Mapped[str | None] = mapped_column(String(120))
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

    # Coordinator/PM validation of the subcontractor's result. A Ready site
    # needs no category; a Not-Ready site is validated by assigning it one of
    # the four problem categories. reviewed_at marks that validation is done.
    reviewed_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    reviewed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

    assignment: Mapped[HcAssignment] = relationship(back_populates="tasks")
    work_item = relationship("WorkItem", back_populates="hc_tasks")
    technologies: Mapped[list[HcTaskTechnology]] = relationship(
        back_populates="task", lazy="selectin", cascade="all, delete-orphan"
    )


class HcTaskTechnology(Base):
    """Per-technology result for one HC task. Only requested techs exist here."""

    __tablename__ = "hc_task_technologies"
    __table_args__ = (
        UniqueConstraint("hc_task_id", "technology", name="uq_hc_task_tech"),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    hc_task_id: Mapped[int] = mapped_column(
        ForeignKey("hc_tasks.id"), nullable=False, index=True
    )
    technology: Mapped[str] = mapped_column(String(10), nullable=False)  # 2G|3G|4G
    result: Mapped[str | None] = mapped_column(String(20))  # Normal|NotNormal|None
    reason_category: Mapped[str | None] = mapped_column(String(120))
    comment: Mapped[str | None] = mapped_column(Text)

    task: Mapped[HcTask] = relationship(back_populates="technologies")
