"""Reference / master data and RBAC models."""
from __future__ import annotations

from sqlalchemy import Boolean, ForeignKey, String, Table, Column, Integer
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.database import Base


class Province(Base):
    __tablename__ = "provinces"

    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(100), unique=True, nullable=False)


class Region(Base):
    __tablename__ = "regions"

    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(100), unique=True, nullable=False)


class Contractor(Base):
    __tablename__ = "contractors"

    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(150), nullable=False)
    # 'site' = execution contractor, 'drive_test' = DT contractor
    type: Mapped[str] = mapped_column(String(20), nullable=False, default="drive_test")
    active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)


class ProblemCategory(Base):
    """Health-check problem categories. Admin-extendable without code changes."""

    __tablename__ = "problem_categories"

    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(120), unique=True, nullable=False)
    active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)


class Role(Base):
    __tablename__ = "roles"

    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(50), unique=True, nullable=False)

    users: Mapped[list[User]] = relationship(back_populates="role")


# Association table: which provinces a user may see (row-level security).
user_province_access = Table(
    "user_province_access",
    Base.metadata,
    Column("user_id", Integer, ForeignKey("users.id", ondelete="CASCADE"), primary_key=True),
    Column("province_id", Integer, ForeignKey("provinces.id", ondelete="CASCADE"), primary_key=True),
)


class User(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(primary_key=True)
    username: Mapped[str] = mapped_column(String(80), unique=True, nullable=False)
    password_hash: Mapped[str] = mapped_column(String(255), nullable=False)
    full_name: Mapped[str] = mapped_column(String(150), nullable=False)

    role_id: Mapped[int] = mapped_column(ForeignKey("roles.id"), nullable=False)
    role: Mapped[Role] = relationship(back_populates="users")

    # Contractor users are scoped to their own assigned work items.
    contractor_id: Mapped[int | None] = mapped_column(
        ForeignKey("contractors.id"), nullable=True
    )
    contractor: Mapped[Contractor | None] = relationship()

    # Admin / PM bypass province filtering entirely.
    sees_all_provinces: Mapped[bool] = mapped_column(
        Boolean, default=False, nullable=False
    )

    active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)

    provinces: Mapped[list[Province]] = relationship(
        secondary=user_province_access, lazy="selectin"
    )
