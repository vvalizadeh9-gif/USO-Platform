"""Pydantic schemas (request/response contracts)."""
from __future__ import annotations

from datetime import date, datetime

from pydantic import BaseModel, ConfigDict, Field


class ORMModel(BaseModel):
    """Base for schemas read from ORM objects."""

    model_config = ConfigDict(from_attributes=True)


# ---------- Auth ----------
class LoginRequest(BaseModel):
    username: str
    password: str


class CaptchaChallenge(BaseModel):
    token: str
    num1: int
    num2: int


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserOut


# ---------- Reference ----------
class ProvinceOut(ORMModel):
    id: int
    name: str


class RegionOut(ORMModel):
    id: int
    name: str


class ContractorOut(ORMModel):
    id: int
    name: str
    type: str
    active: bool


class ContractorCreate(BaseModel):
    name: str
    type: str = "drive_test"


class ProblemCategoryOut(ORMModel):
    id: int
    name: str
    active: bool


class ProblemCategoryCreate(BaseModel):
    name: str


class RoleOut(ORMModel):
    id: int
    name: str


# ---------- Users ----------
class UserOut(ORMModel):
    id: int
    username: str
    full_name: str
    role: RoleOut
    contractor_id: int | None = None
    sees_all_provinces: bool
    active: bool
    provinces: list[ProvinceOut] = []


class UserCreate(BaseModel):
    username: str
    password: str = Field(min_length=8)
    full_name: str
    role_id: int
    contractor_id: int | None = None
    sees_all_provinces: bool = False
    province_ids: list[int] = []


class UserUpdate(BaseModel):
    full_name: str | None = None
    password: str | None = Field(default=None, min_length=8)
    role_id: int | None = None
    contractor_id: int | None = None
    sees_all_provinces: bool | None = None
    province_ids: list[int] | None = None
    active: bool | None = None


# ---------- Work Item / Village ----------
class AcceptanceOut(ORMModel):
    id: int
    technology: str
    ict_status: str
    ict_date: date | None
    cra_status: str
    cra_date: date | None


class VillageOut(ORMModel):
    id: int
    village_code: str | None
    village_name: str | None
    households: int | None
    population: int | None
    acceptances: list[AcceptanceOut] = []


class VillageAcceptanceRow(ORMModel):
    """One row for the Acceptance overview: a village plus its parent work item context."""

    work_item_id: int
    site_type: str
    village: VillageOut


class WorkItemListItem(ORMModel):
    """One row of the Work Items list.

    Carries the union of every column any stage tab needs; the frontend picks
    which subset to render per stage. Fields are None when not applicable
    (e.g. ``dt_approval_date`` before a coordinator has approved), so a single
    endpoint serves all tabs rather than one endpoint per stage.
    """

    id: int
    site_code: str | None = None
    site_type: str
    requested_technology: str | None
    current_stage: str
    project_name: str | None

    # Assignment (latest active, else latest ever)
    assignment_date: datetime | None = None
    assignment_user: str | None = None
    contractor_name: str | None = None
    returned_date: datetime | None = None

    # Drive test (latest active)
    dt_submission_date: date | None = None
    dt_approval_date: datetime | None = None
    dt_approval_user: str | None = None
    # Whole days between assignment and DT submission.
    aging_days: int | None = None


class WorkItemDetail(ORMModel):
    id: int
    site_type: str
    requested_technology: str | None
    deployed_technology: str | None
    project_name: str | None
    pm_name: str | None
    power_status: str | None
    current_stage: str
    villages: list[VillageOut] = []
    # The drive test currently awaiting/holding a decision, if any. The
    # coordinator's approve/reject panel needs its id to act on.
    active_drive_test_id: int | None = None
    dt_submission_date: date | None = None


# ---------- Workflow actions ----------
class HealthCheckCreate(BaseModel):
    status: str  # Ready | Problematic
    problem_category_id: int | None = None
    comment: str | None = None


class AssignmentCreate(BaseModel):
    assignment_type: str  # first | official
    contractor_id: int
    remarks: str | None = None


class BulkAssignmentCreate(BaseModel):
    work_item_ids: list[int] = Field(min_length=1)
    contractor_id: int
    assignment_type: str = "official"  # bulk assign defaults to official
    remarks: str | None = None


class DriveTestCreate(BaseModel):
    execution_date: date | None = None
    report_link: str | None = None


class ReturnToCoordinatorRequest(BaseModel):
    """Contractor hands a site back before attempting drive test."""

    reason: str = Field(min_length=3, max_length=1000)


class ReviewRequest(BaseModel):
    decision: str  # Approved | Rejected | Returned
    comment: str | None = None


class AcceptanceUpdate(BaseModel):
    ict_status: str | None = None
    ict_date: date | None = None
    cra_status: str | None = None
    cra_date: date | None = None


# ---------- Letters ----------
class LetterCreate(BaseModel):
    letter_number: str
    letter_date: date | None = None
    authority: str
    province_id: int | None = None
    comment: str | None = None
    village_ids: list[int] = []


class LetterOut(ORMModel):
    id: int
    letter_number: str
    letter_date: date | None
    authority: str
    attachment_path: str | None
    comment: str | None


class CpmWipeRequest(BaseModel):
    confirm: str  # must exactly match the required confirmation phrase


class CpmWipeResult(BaseModel):
    deleted: dict[str, int]
    total_deleted: int


# ---------- CPM ----------
class CpmImportSummary(ORMModel):
    id: int
    filename: str
    total_rows: int
    new_count: int
    new_villages_count: int = 0
    changed_count: int
    changed_village_qty: int = 0
    changed_site_type: int = 0
    changed_requested_tech: int = 0
    unchanged_count: int
    skipped_satellite: int
    created_at: datetime


class CpmChangeRequestOut(ORMModel):
    id: int
    site_code: str
    change_type: str = "field"
    field_name: str
    old_value: str | None
    new_value: str | None
    detail: str | None = None
    payload_json: str | None = None
    status: str


class CpmDecisionRequest(BaseModel):
    decision: str  # Accepted | Ignored | Archived


# ---------- Notifications ----------
class NotificationOut(ORMModel):
    id: int
    type: str
    message: str
    is_read: bool
    created_at: datetime


# ---------- Action Center ----------
class ActionItem(BaseModel):
    """One concrete thing a user needs to do or knows about, live-derived
    from current state (self-clearing) or a past event folded in from the
    notification log. Never a static/aggregate row — every item points at
    exactly one entity via ``url`` so clicking it goes straight there."""

    id: str
    category: str  # drive_test | assignment | cpm | health_check | event
    label: str
    subtitle: str | None = None
    url: str
    created_at: datetime | None = None
    source: str = "action"  # "action" (derived, clears itself) | "event" (dismissible)


# ---------- Health Check workflow (Phase A) ----------
class HcBasketItem(BaseModel):
    work_item_id: int
    site_code: str | None
    site_type: str
    province: str | None
    requested_technologies: list[str]


class HcAssignmentCreate(BaseModel):
    contractor_id: int
    work_item_ids: list[int] = Field(min_length=1)
    remarks: str | None = None


class HcTechResult(BaseModel):
    technology: str
    result: str  # Normal | NotNormal
    reason_category: str | None = None
    comment: str | None = None


class HcTaskResultSubmit(BaseModel):
    technology_results: list[HcTechResult] = Field(min_length=1)


class HcTechnologyOut(ORMModel):
    technology: str
    result: str | None
    reason_category: str | None
    comment: str | None


class HcTaskOut(ORMModel):
    id: int
    work_item_id: int
    site_code: str | None = None
    site_type: str | None = None
    province: str | None = None
    requested_technologies: list[str] = []
    overall_result: str | None
    problem_category: str | None
    reviewed: bool = False
    technologies: list[HcTechnologyOut] = []


class HcReviewSubmit(BaseModel):
    """Coordinator/PM validation of a completed HC task.

    problem_category is required only for Not-Ready sites (one of the four
    predefined categories); Ready sites send it as null.
    """
    problem_category: str | None = None


class HcAssignmentOut(ORMModel):
    id: int
    code: str
    title: str | None = None
    contractor_id: int
    status: str
    remarks: str | None
    created_at: datetime
    tasks: list[HcTaskOut] = []


class HcAssignmentListItem(ORMModel):
    id: int
    code: str
    contractor_id: int
    status: str
    created_at: datetime
    task_count: int = 0
    # Feedback breakdown for the HC History detail view. All additive/optional
    # so older clients that ignore them keep working unchanged.
    sites_ready: int = 0
    sites_not_ready: int = 0
    sites_pending: int = 0
    feedback_received_at: datetime | None = None
    aging_days: int | None = None
    aging_ongoing: bool = False


class HcResultRow(BaseModel):
    task_id: int | None = None
    work_item_id: int
    site_code: str | None
    site_type: str
    overall_result: str | None
    problem_category: str | None
    reviewed: bool = False
    assignment_code: str
    contractor_name: str | None = None       # the subcontractor (SC) who did the HC
    technologies: list[HcTechnologyOut] = []  # per-technology Normal/NotNormal detail


# ---------- Drive Test Project dashboard ----------
class KpiWithDelta(BaseModel):
    """A KPI value with its month-over-month delta and optional percentage."""

    value: int
    delta: int | None = None          # +/- vs last month; None = no prior data
    percent_of_onair: float | None = None  # share of total on-air, where relevant


class DriveTestKpis(BaseModel):
    total_onair: KpiWithDelta
    total_dt_done: KpiWithDelta
    total_remaining: KpiWithDelta
    total_ongoing: KpiWithDelta
    total_problematic: KpiWithDelta
    current_month_dt_done: KpiWithDelta


class ChartPoint(BaseModel):
    name: str
    value: int


class ProvinceProgressPoint(BaseModel):
    name: str
    onair: int
    done: int
    remaining: int
    done_percent: float


class DriveTestOverview(BaseModel):
    kpis: DriveTestKpis
    ongoing_by_contractor: list[ChartPoint]
    problematic_by_category: list[ChartPoint]
    dt_done_by_contractor: list[ChartPoint]
    dt_done_yearly: list[ChartPoint]
    dt_done_monthly: list[dict]
    progress_by_province: list[ProvinceProgressPoint]
    current_month_label: str


# ----- Acceptance dashboard -----
class AcceptanceKpis(BaseModel):
    """Overview KPI cards. Counts are of every (site, village) row in the
    DT-Done هدف universe — duplicates are not removed."""

    total_dt_done_villages: int
    total_ict_approval: int
    total_ict_remained: int
    total_cra_approval: int
    total_cra_remained: int


class AcceptanceAnalysis(BaseModel):
    """Work-item (site) and village level cross tabs of ICT vs CRA approval."""

    sites_ict_full: int
    sites_cra_full: int
    sites_ict_and_cra_full: int
    sites_ict_not_cra: int
    sites_cra_not_ict: int
    villages_ict_not_cra: int
    villages_cra_not_ict: int


class ProvinceAcceptanceRow(BaseModel):
    """Per-province ICT & CRA approval status."""

    name: str
    total: int
    ict_approved: int
    ict_remained: int
    ict_approved_pct: float
    ict_remained_pct: float
    cra_approved: int
    cra_remained: int
    cra_approved_pct: float
    cra_remained_pct: float


class AcceptanceOverview(BaseModel):
    kpis: AcceptanceKpis
    analysis: AcceptanceAnalysis
    provinces: list[ProvinceAcceptanceRow]


UserOut.model_rebuild()
TokenResponse.model_rebuild()
