"""Action Center, Notifications and reference data endpoints."""
from fastapi import APIRouter, Depends
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.deps import get_current_user
from app.models.acceptance import Notification
from app.models.reference import (
    Contractor,
    ProblemCategory,
    Province,
    Role,
    User,
)
from app.models.workitem import WorkItem
from app.schemas import (
    ActionItem,
    ContractorOut,
    NotificationOut,
    ProblemCategoryOut,
    ProvinceOut,
    RoleOut,
)
from app.services.visibility import apply_work_item_scope
from app.services.workflow import STAGE_READY

router = APIRouter(tags=["misc"])


@router.get("/action-center", response_model=list[ActionItem])
def action_center(
    db: Session = Depends(get_db), user: User = Depends(get_current_user)
) -> list[ActionItem]:
    """Return the current user's pending actions, derived from state."""
    base = apply_work_item_scope(
        select(WorkItem).where(WorkItem.deleted_at.is_(None)), user, db
    )
    work_items = list(db.execute(base).scalars().all())
    items: list[ActionItem] = []

    role = user.role.name
    if role in ("Coordinator", "Admin"):
        dt_waiting = sum(
            1 for w in work_items if w.current_stage == "DT Submitted"
        )
        items.append(ActionItem(label="DT awaiting validation", count=dt_waiting, category="drive_test"))
    if role in ("PM", "Admin"):
        returned = sum(
            1 for w in work_items if w.current_stage == "Returned by Contractor"
        )
        items.append(ActionItem(label="Returned by contractor", count=returned, category="assignment"))
        ready = sum(1 for w in work_items if w.current_stage == STAGE_READY)
        items.append(ActionItem(label="Ready for assignment", count=ready, category="assignment"))
    if role in ("Contractor", "Admin"):
        assigned = sum(1 for w in work_items if w.current_stage == "Assigned")
        items.append(ActionItem(label="Assigned to you", count=assigned, category="assignment"))

    return items


@router.get("/notifications", response_model=list[NotificationOut])
def my_notifications(
    db: Session = Depends(get_db), user: User = Depends(get_current_user)
):
    return (
        db.query(Notification)
        .filter(Notification.user_id == user.id)
        .order_by(Notification.id.desc())
        .limit(50)
        .all()
    )


@router.post("/notifications/{notification_id}/read")
def mark_read(
    notification_id: int,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    notif = db.get(Notification, notification_id)
    if notif and notif.user_id == user.id:
        notif.is_read = True
        db.commit()
    return {"status": "ok"}


# ---------------- Reference data (for dropdowns) ----------------
@router.get("/reference/provinces", response_model=list[ProvinceOut])
def list_provinces(db: Session = Depends(get_db), _: User = Depends(get_current_user)):
    """Return only the 31 canonical Iranian provinces.

    Older databases may still contain stray province rows created before
    canonical mapping existed (site codes / work-item strings that leaked into
    the استان column). We filter to the canonical set here so "Grant province
    access" always shows exactly the 31 real provinces, never junk.
    """
    from app.services.cpm_columns import CANONICAL_PROVINCE_BY_NORM, normalize_persian

    provinces = db.query(Province).order_by(Province.name).all()
    return [
        p for p in provinces
        if normalize_persian(p.name) in CANONICAL_PROVINCE_BY_NORM
    ]


@router.get("/reference/roles", response_model=list[RoleOut])
def list_roles(db: Session = Depends(get_db), _: User = Depends(get_current_user)):
    return db.query(Role).order_by(Role.id).all()


@router.get("/reference/contractors", response_model=list[ContractorOut])
def list_contractors(db: Session = Depends(get_db), _: User = Depends(get_current_user)):
    return db.query(Contractor).filter(Contractor.active.is_(True)).all()


@router.get("/reference/problem-categories", response_model=list[ProblemCategoryOut])
def list_problem_categories(
    db: Session = Depends(get_db), _: User = Depends(get_current_user)
):
    return db.query(ProblemCategory).filter(ProblemCategory.active.is_(True)).all()
