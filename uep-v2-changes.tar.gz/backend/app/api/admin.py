"""Admin module endpoints: CPM import, user management, CPM validation."""
import os
import shutil
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
from sqlalchemy.orm import Session

from app.core.config import get_settings
from app.core.database import get_db
from app.core.deps import ADMIN, COORDINATOR, PM, require_roles
from app.core.security import hash_password
from app.models.acceptance import CpmChangeRequest, CpmImportBatch
from app.models.reference import Province, Role, User, user_province_access
from app.models.workitem import WorkItem
from app.schemas import (
    CpmChangeRequestOut,
    CpmDecisionRequest,
    CpmImportSummary,
    CpmWipeRequest,
    CpmWipeResult,
    UserCreate,
    UserOut,
    UserUpdate,
)
from app.services.audit import record_audit
from app.services.cpm_import import CpmImportService
from app.services.data_wipe import REQUIRED_CONFIRMATION_PHRASE, wipe_cpm_data

router = APIRouter(prefix="/admin", tags=["admin"])
settings = get_settings()


# ---------------- Tab 1: CPM Import ----------------
@router.post("/cpm/import", response_model=CpmImportSummary)
def import_cpm(
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    user: User = Depends(require_roles(ADMIN)),
):
    """Upload and process a monthly CPM Excel file."""
    if not file.filename.lower().endswith((".xlsx", ".xls")):
        raise HTTPException(400, "Only Excel files are accepted")

    os.makedirs(settings.upload_dir, exist_ok=True)
    dest = os.path.join(
        settings.upload_dir,
        f"cpm_{datetime.now(timezone.utc):%Y%m%d%H%M%S}_{file.filename}",
    )
    with open(dest, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)

    service = CpmImportService(db, user_id=user.id)
    batch = service.import_file(dest, file.filename)
    return batch


@router.get("/cpm/import-history", response_model=list[CpmImportSummary])
def cpm_import_history(
    limit: int = 50,
    db: Session = Depends(get_db),
    _: User = Depends(require_roles(ADMIN)),
):
    """List past CPM import batches, most recent first, for the history panel."""
    return (
        db.query(CpmImportBatch)
        .order_by(CpmImportBatch.created_at.desc())
        .limit(limit)
        .all()
    )


@router.post("/cpm/wipe-data", response_model=CpmWipeResult)
def wipe_cpm_import_data(
    payload: CpmWipeRequest,
    db: Session = Depends(get_db),
    user: User = Depends(require_roles(ADMIN)),
):
    """Erase all CPM-imported data (sites, work items, villages, acceptances,
    letters, import history, monthly snapshots). Users, roles, contractors,
    provinces, and problem categories are preserved.

    Requires the exact confirmation phrase to guard against accidental calls,
    including direct API calls that bypass the UI's confirmation dialog.
    """
    if payload.confirm != REQUIRED_CONFIRMATION_PHRASE:
        raise HTTPException(
            400,
            f"Confirmation phrase did not match. Expected exactly: "
            f"'{REQUIRED_CONFIRMATION_PHRASE}'",
        )

    deleted = wipe_cpm_data(db)
    total = sum(deleted.values())

    record_audit(
        db,
        user_id=user.id,
        module="Admin",
        entity_type="CpmDataWipe",
        entity_id=None,
        new_value=deleted,
        reason="Manual CPM data wipe requested from Admin Console",
    )
    db.commit()

    return CpmWipeResult(deleted=deleted, total_deleted=total)


# ---------------- Tab 3: Validate CPM ----------------
@router.get("/cpm/change-requests", response_model=list[CpmChangeRequestOut])
def list_change_requests(
    db: Session = Depends(get_db),
    _: User = Depends(require_roles(ADMIN, PM)),
):
    """List pending CPM change requests awaiting a decision."""
    return (
        db.query(CpmChangeRequest)
        .filter(CpmChangeRequest.status == "Pending")
        .order_by(CpmChangeRequest.id.desc())
        .all()
    )


@router.get("/cpm/change-requests/count")
def pending_change_request_count(
    db: Session = Depends(get_db),
    _: User = Depends(require_roles(ADMIN, PM, COORDINATOR)),
):
    """Count of pending CPM change requests, for the Validate CPM badge."""
    count = (
        db.query(CpmChangeRequest)
        .filter(CpmChangeRequest.status == "Pending")
        .count()
    )
    return {"pending": count}


@router.post("/cpm/change-requests/{cr_id}/decide")
def decide_change_request(
    cr_id: int,
    payload: CpmDecisionRequest,
    db: Session = Depends(get_db),
    user: User = Depends(require_roles(ADMIN, PM)),
):
    """Accept / Ignore / Archive a CPM change request.

    Accept applies the new value to the work item; the others just close it.
    """
    cr = db.get(CpmChangeRequest, cr_id)
    if cr is None:
        raise HTTPException(404, "Change request not found")
    if cr.status != "Pending":
        raise HTTPException(400, "Change request already decided")

    if payload.decision == "Accepted":
        from app.services.cpm_apply import apply_change_request

        apply_change_request(db, cr)

    cr.status = payload.decision
    cr.decided_by = user.id
    cr.decided_at = datetime.now(timezone.utc)
    record_audit(
        db, user_id=user.id, module="CPM", entity_type="CpmChangeRequest",
        entity_id=cr.id, new_value={"decision": payload.decision},
    )
    db.commit()
    return {"status": "ok"}


# ---------------- Tab 2: User Management ----------------
@router.get("/users", response_model=list[UserOut])
def list_users(
    db: Session = Depends(get_db), _: User = Depends(require_roles(ADMIN))
):
    return db.query(User).order_by(User.id).all()


@router.post("/users", response_model=UserOut, status_code=201)
def create_user(
    payload: UserCreate,
    db: Session = Depends(get_db),
    admin: User = Depends(require_roles(ADMIN)),
):
    if db.query(User).filter(User.username == payload.username).first():
        raise HTTPException(400, "Username already exists")

    user = User(
        username=payload.username,
        password_hash=hash_password(payload.password),
        full_name=payload.full_name,
        role_id=payload.role_id,
        contractor_id=payload.contractor_id,
        sees_all_provinces=payload.sees_all_provinces,
    )
    _set_provinces(db, user, payload.province_ids)
    db.add(user)
    db.flush()
    record_audit(
        db, user_id=admin.id, module="Admin", entity_type="User",
        entity_id=user.id, new_value={"username": user.username},
    )
    db.commit()
    db.refresh(user)
    return user


@router.patch("/users/{user_id}", response_model=UserOut)
def update_user(
    user_id: int,
    payload: UserUpdate,
    db: Session = Depends(get_db),
    admin: User = Depends(require_roles(ADMIN)),
):
    user = db.get(User, user_id)
    if user is None:
        raise HTTPException(404, "User not found")

    if payload.full_name is not None:
        user.full_name = payload.full_name
    if payload.password is not None:
        user.password_hash = hash_password(payload.password)
    if payload.role_id is not None:
        user.role_id = payload.role_id
    # contractor_id needs special handling: None is a valid value here
    # (clearing the contractor when a user's role changes away from
    # Contractor). "is not None" would silently ignore that clear, so we
    # check whether the field was explicitly sent instead.
    if "contractor_id" in payload.model_fields_set:
        user.contractor_id = payload.contractor_id
    if payload.sees_all_provinces is not None:
        user.sees_all_provinces = payload.sees_all_provinces
    if payload.active is not None:
        user.active = payload.active
    if payload.province_ids is not None:
        _set_provinces(db, user, payload.province_ids)

    record_audit(
        db, user_id=admin.id, module="Admin", entity_type="User",
        entity_id=user.id, reason="User updated",
    )
    db.commit()
    db.refresh(user)
    return user


@router.delete("/users/{user_id}")
def delete_user(
    user_id: int,
    db: Session = Depends(get_db),
    admin: User = Depends(require_roles(ADMIN)),
):
    """Permanently delete a user.

    Guards: an admin can't delete their own account, and the last remaining
    active admin can't be deleted (which would lock everyone out).
    """
    user = db.get(User, user_id)
    if user is None:
        raise HTTPException(404, "User not found")
    if user.id == admin.id:
        raise HTTPException(400, "You cannot delete your own account.")
    if user.role and user.role.name == ADMIN:
        other_admins = (
            db.query(User)
            .join(User.role)
            .filter(Role.name == ADMIN, User.id != user.id, User.active.is_(True))
            .count()
        )
        if other_admins == 0:
            raise HTTPException(400, "Cannot delete the last administrator.")

    username = user.username
    user.provinces = []  # clear m2m rows first
    db.delete(user)
    record_audit(
        db, user_id=admin.id, module="Admin", entity_type="User",
        entity_id=user_id, reason=f"User '{username}' deleted",
    )
    db.commit()
    return {"status": "ok", "deleted": username}


def _set_provinces(db: Session, user: User, province_ids: list[int]) -> None:
    """Replace the user's province grants with the given list."""
    provinces = (
        db.query(Province).filter(Province.id.in_(province_ids)).all()
        if province_ids
        else []
    )
    user.provinces = provinces
