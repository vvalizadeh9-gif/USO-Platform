"""Authentication endpoints."""
from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.security import create_access_token, verify_password
from app.models.reference import User
from app.schemas import TokenResponse, UserOut

router = APIRouter(prefix="/auth", tags=["auth"])


@router.post("/login", response_model=TokenResponse)
def login(
    form: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)
) -> TokenResponse:
    """Validate credentials and return a JWT plus the user profile."""
    user = db.query(User).filter(User.username == form.username).one_or_none()
    if user is None or not verify_password(form.password, user.password_hash):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username or password",
        )
    if not user.active:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN, detail="Account is disabled"
        )
    # Lazily ensure this Shamsi month has a KPI snapshot (for month-over-month
    # deltas). Failure here must never block login, so guard it.
    try:
        from app.services.snapshots import ensure_current_month_snapshot

        ensure_current_month_snapshot(db)
    except Exception:  # pragma: no cover - snapshot is best-effort
        db.rollback()

    token = create_access_token(user.id, {"role": user.role.name})
    return TokenResponse(access_token=token, user=UserOut.model_validate(user))
