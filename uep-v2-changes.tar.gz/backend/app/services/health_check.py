"""Health Check workflow service (Phase A).

Encapsulates: the HC basket (on-air sites needing a health check), creating
assignments, submitting per-technology results, and the auto-computation of
each site's overall Ready / NotReady outcome.

Site readiness is derived, never entered manually: a site is Ready only when
every requested technology is marked Normal; otherwise NotReady, and the
problem category is taken from the first failing technology.
"""
from __future__ import annotations

from datetime import datetime, timezone

from sqlalchemy import select
from sqlalchemy.orm import Session, selectinload

from app.models.health_check import HcAssignment, HcTask, HcTaskTechnology
from app.models.workitem import Site, WorkItem
from app.services import cpm_columns as C
from app.services.tech_parser import parse_technologies
from app.services.visibility import apply_work_item_scope
from app.services.workflow import refresh_stage


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _as_aware(dt: datetime | None) -> datetime | None:
    """Coerce a possibly-naive datetime to UTC-aware.

    Postgres stores our timestamps tz-aware, but a naive value can slip in via
    SQLite (tests) or older rows. Normalising here keeps date subtraction from
    raising on a naive/aware mismatch.
    """
    if dt is None:
        return None
    if dt.tzinfo is None:
        return dt.replace(tzinfo=timezone.utc)
    return dt


def build_assignment_stats(assignment: HcAssignment) -> dict:
    """Aggregate feedback metrics for one assignment (used by history + export).

    Returns per-assignment counts plus timing:
      * sites_assigned / sites_ready / sites_not_ready / sites_pending
      * assigned_at            — when the assignment was created
      * feedback_received_at   — when the LAST site's result arrived; only set
        once every site has feedback (i.e. the assignment is fully complete),
        otherwise None (feedback still outstanding)
      * aging_days             — assignment date → feedback date, in whole days;
        while feedback is still outstanding this counts up to "now" instead and
        ``aging_ongoing`` is True
    """
    tasks = list(assignment.tasks)
    sites_assigned = len(tasks)
    sites_ready = sum(1 for t in tasks if t.overall_result == "Ready")
    sites_not_ready = sum(1 for t in tasks if t.overall_result == "NotReady")
    completed_dates = [
        _as_aware(t.completed_at) for t in tasks if t.completed_at is not None
    ]
    sites_pending = sites_assigned - len(completed_dates)

    assigned_at = _as_aware(assignment.assigned_at)
    # Feedback is "received" only when every site has reported back.
    feedback_received_at = (
        max(completed_dates)
        if completed_dates and len(completed_dates) == sites_assigned
        else None
    )

    aging_days: int | None = None
    aging_ongoing = False
    if assigned_at is not None:
        end = feedback_received_at or _now()
        aging_ongoing = feedback_received_at is None
        aging_days = max((end - assigned_at).days, 0)

    return {
        "sites_assigned": sites_assigned,
        "sites_ready": sites_ready,
        "sites_not_ready": sites_not_ready,
        "sites_pending": sites_pending,
        "assigned_at": assigned_at,
        "feedback_received_at": feedback_received_at,
        "aging_days": aging_days,
        "aging_ongoing": aging_ongoing,
    }


def generate_assignment_code(db: Session) -> str:
    """Produce a friendly sequential code like HC-2026-0001."""
    year = _now().year
    count = db.query(HcAssignment).count() + 1
    return f"HC-{year}-{count:04d}"


def work_item_ids_in_open_hc(db: Session) -> set[int]:
    """IDs of work items that already have a not-yet-completed HC task.

    Used to keep the basket clean — a site being health-checked shouldn't
    reappear in the 'needs assignment' basket.
    """
    rows = (
        db.query(HcTask.work_item_id)
        .filter(HcTask.completed_at.is_(None))
        .all()
    )
    return {r[0] for r in rows}


def completed_hc_work_item_ids(db: Session) -> set[int]:
    """IDs of work items with a completed HC task (Ready or NotReady)."""
    rows = db.query(HcTask.work_item_id).filter(HcTask.completed_at.isnot(None)).all()
    return {r[0] for r in rows}


def get_basket(db: Session, user) -> list[dict]:
    """On-air sites that still need a health check, scoped to the user.

    'Needs HC' = on-air AND not currently in an open HC task AND not already
    completed. Each row carries its requested technologies so the UI can show
    only those.
    """
    stmt = select(WorkItem).where(WorkItem.deleted_at.is_(None))
    stmt = apply_work_item_scope(stmt, user, db)
    stmt = stmt.options(selectinload(WorkItem.site).selectinload(Site.province))
    work_items = db.execute(stmt).scalars().all()

    busy = work_item_ids_in_open_hc(db)
    done = completed_hc_work_item_ids(db)

    basket = []
    for wi in work_items:
        if C.normalize_stage(wi.last_stage) not in C.ONAIR_STAGES:
            continue
        # Exclude sites whose drive test is already Done or Ongoing — they do
        # not belong in the health-check basket (only sites still awaiting DT,
        # i.e. blank or Problematic DT status, are eligible).
        if C.normalize_dt_status(wi.dt_status) in C.DT_STATUS_EXCLUDED_FROM_HC:
            continue
        if wi.id in busy or wi.id in done:
            continue
        basket.append(
            {
                "work_item_id": wi.id,
                "site_code": wi.site.site_code if wi.site else None,
                "site_type": wi.site_type,
                "province": wi.site.province.name if wi.site and wi.site.province else None,
                "requested_technologies": parse_technologies(wi.requested_technology),
            }
        )
    return basket


def create_assignment(
    db: Session, *, contractor_id: int, work_item_ids: list[int], user
) -> HcAssignment:
    """Create an HC assignment containing one task per given site."""
    assignment = HcAssignment(
        code=generate_assignment_code(db),
        contractor_id=contractor_id,
        assigned_by=user.id,
        assigned_at=_now(),
        status="Open",
    )
    db.add(assignment)
    db.flush()

    for wi_id in work_item_ids:
        task = HcTask(hc_assignment_id=assignment.id, work_item_id=wi_id)
        db.add(task)

    db.flush()
    return assignment


def submit_task_result(
    db: Session, *, task: HcTask, technology_results: list[dict]
) -> HcTask:
    """Apply the subcontractor's per-technology results and compute readiness.

    ``technology_results`` is a list of dicts:
        {technology, result ('Normal'|'NotNormal'), comment?}

    Business rules enforced:
      * a comment is required when result == 'NotNormal'
      * overall Ready only if every technology is Normal; any NotNormal ⇒
        NotReady
      * the subcontractor does NOT choose a problem category — that is done
        later by a Coordinator/PM during validation. Submitting (or
        re-submitting) a result therefore clears any prior category and
        resets the review state.
    """
    # Replace any existing technology rows for idempotent re-submission.
    task.technologies.clear()
    db.flush()

    any_not_normal = False

    for entry in technology_results:
        tech = entry["technology"]
        result = entry["result"]
        comment = entry.get("comment")

        if result == "NotNormal":
            any_not_normal = True

        task.technologies.append(
            HcTaskTechnology(
                technology=tech,
                result=result,
                reason_category=None,  # category is coordinator-owned now
                comment=comment if result == "NotNormal" else None,
            )
        )

    task.overall_result = "NotReady" if any_not_normal else "Ready"
    # Category & review are coordinator-owned; a fresh submission resets them.
    task.problem_category = None
    task.reviewed_by = None
    task.reviewed_at = None
    task.completed_at = _now()

    db.flush()
    # Bridge into the lifecycle: a completed HC advances the work item to
    # "Ready for Assignment" (or "Problematic"), which surfaces it in the
    # PM's assignment queue and Action Center. Assignment/DT states already
    # take precedence inside derive_stage, so this never regresses a site.
    if task.work_item is not None:
        refresh_stage(task.work_item)
    _maybe_complete_assignment(db, task.hc_assignment_id)
    return task


def review_task(
    db: Session, *, task: HcTask, problem_category: str | None, user
) -> HcTask:
    """Coordinator/PM validation of a completed HC task.

    * A **Ready** site needs no category (validation just acknowledges it).
    * A **Not Ready** site must be assigned one of the four problem
      categories; that category is stored on the task.

    Raises ``ValueError`` on invalid input so the API can return 400.
    """
    if task.completed_at is None or task.overall_result is None:
        raise ValueError("This site has no submitted result to validate yet.")

    if task.overall_result == "NotReady":
        if not problem_category:
            raise ValueError("A Not-Ready site must be assigned a problem category.")
        task.problem_category = problem_category
    else:  # Ready
        task.problem_category = None

    task.reviewed_by = user.id
    task.reviewed_at = _now()
    db.flush()
    return task


def _maybe_complete_assignment(db: Session, assignment_id: int) -> None:
    """Mark an assignment Completed once all its tasks have a result."""
    assignment = db.get(HcAssignment, assignment_id)
    if assignment is None:
        return
    pending = [t for t in assignment.tasks if t.completed_at is None]
    assignment.status = "Completed" if not pending else "Open"


def requested_techs_for_task(task: HcTask) -> list[str]:
    """The technologies to ask about for a task's site (requested only)."""
    wi = task.work_item
    return parse_technologies(wi.requested_technology) if wi else []


def build_assignment_out(assignment: HcAssignment) -> dict:
    """Build an enriched assignment payload with site info per task.

    Enriches each task with site_code / site_type / province / requested
    technologies so the subcontractor form needs no extra work-item lookup
    (which contractors aren't scoped to see anyway). Also builds the
    "HC-0001 || July-2026" style title from the assignment date.
    """
    month_label = ""
    if assignment.assigned_at:
        month_label = assignment.assigned_at.strftime("%B-%Y")
    title = f"{assignment.code} || {month_label}" if month_label else assignment.code

    tasks_out = []
    for task in assignment.tasks:
        wi = task.work_item
        site = wi.site if wi else None
        tasks_out.append(
            {
                "id": task.id,
                "work_item_id": task.work_item_id,
                "site_code": site.site_code if site else None,
                "site_type": wi.site_type if wi else None,
                "province": site.province.name if site and site.province else None,
                "requested_technologies": requested_techs_for_task(task),
                "overall_result": task.overall_result,
                "problem_category": task.problem_category,
                "reviewed": task.reviewed_at is not None,
                "technologies": [
                    {
                        "technology": t.technology,
                        "result": t.result,
                        "reason_category": t.reason_category,
                        "comment": t.comment,
                    }
                    for t in task.technologies
                ],
            }
        )

    return {
        "id": assignment.id,
        "code": assignment.code,
        "title": title,
        "contractor_id": assignment.contractor_id,
        "status": assignment.status,
        "remarks": assignment.remarks,
        "created_at": assignment.assigned_at,
        "tasks": tasks_out,
    }
